﻿Public Class Node

End Class
